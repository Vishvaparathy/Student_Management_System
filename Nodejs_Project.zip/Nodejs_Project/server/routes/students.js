const express = require("express");
const router = express.Router();
const studentcontrollers = require("../controllers/studentcontrollers");

//View All Records
router.get("/", studentcontrollers.view);

//Add New Records
router.get("/adduser", studentcontrollers.adduser);
router.post("/adduser", studentcontrollers.save);

//Update Records
router.get("/edituser/:id", studentcontrollers.edituser);
router.post("/edituser/:id", studentcontrollers.edit);

//Delete Records
router.get("/deleteuser/:id", studentcontrollers.delete);

module.exports = router;