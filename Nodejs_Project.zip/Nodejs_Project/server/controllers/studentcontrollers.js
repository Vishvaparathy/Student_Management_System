const mysql = require("mysql");


const con = mysql.createPool({
    connectionLimit: 10,
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME
});

exports.view = (req, res) => {
    con.getConnection((err, connection) => {
        if (err) throw err
        connection.query("SELECT * FROM users", (err, rows) => {
            connection.release();
            if (!err) {
               
                res.render("home", {rows});
            } else {
                console.log("Error in Listing data" + err);
            }
        });
        console.log("connection success");
    });

    
};

exports.adduser = (req, res) => {
    res.render("adduser");
}

exports.save = (req, res) => {
    con.getConnection((err, connection) => {
        if (err) throw err

        const { id, name, age, city } = req.body;

        connection.query(
            "INSERT INTO users (ID, NAME, AGE, CITY) VALUES (?, ?, ?, ?)",
            [id, name, age, city],
            (err, rows) => {
                connection.release();
                if (!err) {
                    res.render("adduser", { msg: "User Details Added Successfully" });
                } else {
                    console.log("Error in Listing data: " + err);
                }
            }
        );

        });
        
};

exports.edituser = (req, res) => {
    con.getConnection((err, connection) => {
        if (err) throw err
        //Get ID from url
        let id = req.params.id;

        connection.query("SELECT * FROM users where id=?",[id], (err, rows) => {
            connection.release();

            if (!err) {

                res.render("edituser", { rows });
            } else {
                console.log("Error in Listing data" + err);
            }
        });
        console.log("connection success");
    });


   
}
exports.edit = (req, res) => {
    con.getConnection((err, connection) => {
        if (err) {
            console.error("Database connection error: ", err);
            return res.status(500).send("Internal Server Error"); // Handle connection error
        }

        const { name, age, city } = req.body;
        let id = req.params.id;

        connection.query(
            "UPDATE users SET NAME = ?, AGE = ?, CITY = ? WHERE ID = ?",
            [name, age, city, id], // Correct parameter order
            (err, rows) => {
                connection.release();
                if (!err) {
                    res.render("adduser", { msg: "User Details Updated Successfully" });
                } else {
                    console.error("Error in Updating data: ", err);
                    res.render("edituser", { msg: "Error in Updating Data" });
                }
            }
        );
    });
};

exports.delete = (req, res) => {
    con.getConnection((err, connection) => {
        if (err) throw err
        //Get ID from url
        let id = req.params.id;
        connection.query("delete from users where id=?",
            [id], (err, rows) => {
                connection.release();
                if (!err) {
                    res.redirect("/");

                } else {
                    console.log(err)
                }
        });
    });
}